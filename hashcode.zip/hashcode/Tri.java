package hashcode;

public class Tri {
	public static void trier(int[][] t) {
		int n =t.length;
		for(int i=n;i>=1;i--) {
			for (int j=2;j<=i;j++) {
				if (t[0][j-1]>t[0][j]) {
					int tempr =t[0][j-1];
					int tem=t[1][j-1];
					t[0][j-1]=t[0][j];
					t[1][j-1]=t[1][j];
					t[0][j]=tempr;
					t[1][j]=tem;
					
				}
			}
			
		}
	}
	
}
