package hashcode;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class JavaReadTexteFile {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
	     ReadFile rf = new ReadFile();
         
	        // The text file location of your choice
	     File file = new File("/home/anas/eclipse-workspace/episousse.ex3/src/hashcode/first.txt"); //Your file
	       FileOutputStream fos = new FileOutputStream(file);
	       PrintStream ps = new PrintStream(fos);
	       System.setOut(ps);
	        String filename = "/home/anas/eclipse-workspace/episousse.ex3/src/hashcode/c_memorable_moments.txt";
	        int[][] t ;
	        int[] result;
	        int dim=0;
            
	       
	        try
	        {
	          
	          String[] lines = rf.readLines(filename);
	          t =new int[2][lines.length];
	         int   d=0;
	          for (int i=1;i<lines.length;i++) {
	        	  t[0][d]=i-1;
	        	  if (lines[i].charAt(3)!=' ') {
	        	  t[1][d]=Integer.parseInt(lines[i].substring(2,4));
	        	  }
	        	  else 
	        	  t[1][d]=Character.getNumericValue(lines[i].charAt(2));
	
	        	  d++;
	        	  
	        	  
	        	  
	          }
	      	int n =lines.length-1;
			for(int i=n;i>=0;i--) {
				for (int j=1;j<=i;j++) {
					if (t[1][j-1]<t[1][j]) {
						int tempr =t[0][j-1];
						int tem=t[1][j-1];
						t[0][j-1]=t[0][j];
						t[1][j-1]=t[1][j];
						t[0][j]=tempr;
						t[1][j]=tem;
						
					}
				}
				
			}
			int p=0;
			int max = 0;
			int c =0;
		    do {
		    for (int m=1;m<t.length/3;m++) {
		    
		    Tags S = new Tags(lines[t[0][p]+1],lines[t[0][m]+1]); 
		    if (S.MinScore()>max) {
		    	max=S.MinScore();
		    	d=m;
		    }
		    }
		    t[0][p]=t[0][c];
		    t[1][p]=t[1][c] ;
		    p++;
		    }while (p<t.length);
			result =new int[1000000];
	       for (int i=0;i<n-1;i++) {
	    	 if (lines[t[0][i]+1].charAt(0)!='V') {
	    		result[dim]=t[0][i];
	    		dim++;
	    	 }
	    	 
	       }
	       System.out.println(dim);
	       for (int h=0;h<dim;h++) 
	       {
	    	   System.out.println(result[h]);
	       }
	      
	        } 
	          
	        catch(IOException e)
	        {
	            // Print out the exception that occurred
	            System.out.println("Unable to create "+filename+": "+e.getMessage());              
	        }
	}

}
