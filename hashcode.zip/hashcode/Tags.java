package hashcode;

public class Tags {
	String tag1l[] ;
	String tag2l[];
    String tag1;
    String tag2;
	public Tags (String tag1 ,String tag2) {
		int j=0;
        tag1l =new String[tag2.charAt(2)] ;
        tag2l =new String[tag1.charAt(2)];
        tag1l[0]="";
        tag2l[0]="";
    	for (int i=4;i<tag1.length();i++) {
			if (tag1.charAt(i)!=' ' ){
				tag1l[j]=tag1l[j]+tag1.charAt(i);
					
			}
			else {j++;
			      tag1l[j]="";
			}
		}
		j=0;
		tag2l[j]="";
		for (int i=4;i<tag2.length();i++) {
			if (tag2.charAt(i)!=' ' ){
				tag2l[j]=tag2l[j]+tag2.charAt(i);
					
			}
			else {
				  j++;
			      tag2l[j]="";
			}
		}
  
	}
	public int  CommunTags() {
		int commun = 0;
	 for (int i=0;i<this.tag1l.length;i++) {
		 for (int j=0;j<this.tag2l.length;j++) {
			 if (tag1l[i].equals(tag2l[j])) {
				 commun++;
				 
			 }
		 }
	 }
	 return commun;

	}
	public int MinScore () {
		if  ( (int)tag1.charAt(2)-this.CommunTags() < (int)tag2.charAt(2)-this.CommunTags()  && (int)tag1.charAt(2)<this.CommunTags() ) {
			return (int)tag1.charAt(2);
		} 
		else if  ( (int)tag1.charAt(2)-this.CommunTags() >(int)tag2.charAt(2)-this.CommunTags()  && (int)tag2.charAt(2)<this.CommunTags() ) {
			return (int)tag2.charAt(2);
		} 
		else return (int)this.CommunTags();	
		
	}

}
